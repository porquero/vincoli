var
        sel_msg = 'Debes elegir una asignatura.',
        del_msg = '¿Seguro que quieres eliminar esta asignatura?';

$('#modificar').on('click', function() {
    $(this).blur();
    if ($('.listado').find("input[type=radio]:checked").length === 1) {
        $('#crud h3').text($(this).val());

        var row = $('.listado').find("input[type=radio]:checked").data('row');
        $('#glosa').val(row.glosa);

        $('#enviar').val($(this).val());
        $('#crud').slideDown();
    } else {
        alert(sel_msg);
    }
});

$('#agregar').on('click', function() {
    $('.listado').find("input[type=radio]").prop('checked', false);
    $('#crud h3').text($(this).val());

    $('#glosa').val('');

    $('#enviar').val($(this).val());
    $('#crud').slideDown();
});

$('#eliminar').on('click', function(e) {
    $(this).blur();
    if ($('.listado').find("input[type=radio]:checked").length === 0) {
        e.preventDefault();
        alert(sel_msg);
    } else {
        $('#crud').slideUp();
        if (window.confirm(del_msg) === true) {
            $('#glosa').prop('disabled', true);
        } else {
            e.preventDefault();
        }
    }
});