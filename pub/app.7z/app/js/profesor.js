var
        sel_msg = 'Debes elegir un profesor/a.',
        del_msg = '¿Seguro que quieres eliminar este profesor?';

$('#modificar').on('click', function() {
    $(this).blur();
    if ($('.listado').find("input[type=radio]:checked").length === 1) {
        $('#crud h3').text($(this).val());

        var row = $('.listado').find("input[type=radio]:checked").data('row');
        $('#nombres').val(row.nombres);
        $('#apellidos').val(row.apellidos);
        $('#horas_contrato').val(row.horas_contrato);
        $('#horas_aula').val(row.horas_aula);
        $('#horas_no_lectivas').val(row.horas_no_lectivas);
        $('#horas_permanencia').val(row.horas_permanencia);
        $('#trabajo_tecnico').val(row.trabajo_tecnico);
        $('#comentario').val(row.comentario);

        // Setea los bloques disponibles y la especialidad del profesor.
        $('#crud input[type=checkbox]').prop('checked', false);
        $.ajax({
            url: url_base + 'index.php/admin/profesor/info/' + row.id
        }).done(function(data) {
            data = $.parseJSON(data);
            disponibilidad = $.parseJSON(data['disponibilidad']);
            disponibilidad_especialidad = $.parseJSON(data['disponibilidad_especialidad']);

            // Marca la disponibilidad del profesor.
            $.each(disponibilidad, function(k, v) {
                $('#' + v.id_check).prop('checked', true);
            });

            // Marca los cursos del profesor.
            $.each(disponibilidad_especialidad.cursos, function(k, v) {
                $('#curso_' + v.id_curso).prop('checked', true);
            });

            // Marca las asignaturas del profesor.
            $.each(disponibilidad_especialidad.asignaturas, function(k, v) {
                $('#asignatura_' + v.id_asignatura).prop('checked', true);
            });
        });

        // Elimina la especialidad utilizada como template.
        $('.especialidad').first().remove();

        $('#enviar').val($(this).val());
        $('#crud').slideDown();
        $('#nombres').focus();
    } else {
        alert(sel_msg);
    }
});

$('#agregar').on('click', function() {
    $(this).blur();
    $('.listado').find("input[type=radio]").prop('checked', false);
    $('#crud h3').text($(this).val());

    $('#crud input[type=checkbox]').prop('checked', false);
    $('#nombres').val('');
    $('#apellidos').val('');
    $('#horas_contrato').val('');
    $('#horas_aula').val('');
    $('#horas_no_lectivas').val('');
    $('#horas_permanencia').val('');
    $('#trabajo_tecnico').val('');
    $('#comentario').val('');

    $('#enviar').val($(this).val());
    $('#crud').slideDown();
    $('#nombres').focus();
});

$('#eliminar').on('click', function(e) {
    if ($('.listado').find("input[type=radio]:checked").length === 0) {
        e.preventDefault();
        alert(sel_msg);
    } else {
        $('#crud').slideUp();
        if (window.confirm(del_msg) === true) {
            $('#nombres').prop('disabled', true);
            $('#apellidos').prop('disabled', true);
            $('#horas_contrato').prop('disabled', true);
            $('#horas_aula').prop('disabled', true);
        } else {
            e.preventDefault();
        }
    }
});

$('#crud').tshift();