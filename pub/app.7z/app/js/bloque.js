var
        sel_msg = 'Debes elegir un bloque.',
        del_msg = '¿Seguro que quieres eliminar este bloque?';

$('#modificar').on('click', function() {
    $(this).blur();
    if ($('.listado').find("input[type=radio]:checked").length === 1) {
        $('#crud h3').text($(this).val());

        var row = $('.listado').find("input[type=radio]:checked").data('row');
        $('#rango').val(row.rango);
        $('#comentario').val(row.comentario);

        $('#enviar').val($(this).val());
        $('#crud').slideDown();
    } else {
        alert(sel_msg);
    }
});

$('#agregar').on('click', function() {
    $(this).blur();
    $('.listado').find("input[type=radio]").prop('checked', false);
    $('#crud h3').text($(this).val());

    $('#rango').val('');
    $('#comentario').val('');

    $('#enviar').val($(this).val());
    $('#crud').slideDown();
});

$('#eliminar').on('click', function(e) {
    if ($('.listado').find("input[type=radio]:checked").length === 0) {
        e.preventDefault();
        alert(sel_msg);
    } else {
        $('#crud').slideUp();
        if (window.confirm(del_msg) === true) {
            $('#rango').prop('disabled', true);
        } else {
            e.preventDefault();
        }
    }
});