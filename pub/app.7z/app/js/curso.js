var
        sel_msg = 'Debes elegir un curso.',
        del_msg = '¿Seguro que quieres eliminar este curso?',
        plan_tpl = $('.plan').first().clone();

setear_plan = function(asignatura, horas) {
    var otro_plan = plan_tpl.clone();
    otro_plan.find('.asignatura').val(asignatura);
    otro_plan.find('.horas').val(horas);
    otro_plan.appendTo($('#plan_estudio'));
    FORMALIZE.go();

    return otro_plan;
};

resetear_planes = function() {
    $('.plan').remove();
    plan_tpl.appendTo($('#plan_estudio'));
};

$('#modificar').on('click', function() {
    $(this).blur();
    if ($('.listado').find("input[type=radio]:checked").length === 1) {
        $('#crud h3').text($(this).val());

        var row = $('.listado').find("input[type=radio]:checked").data('row');
        $('#glosa').val(row.glosa);
        $('#id_profesor').val(row.id_profesor);
        $('#comentario').val(row.comentario);

        // Setea el plan de estudios del curso.
        resetear_planes();
        $.ajax({
            url: url_base + 'index.php/admin/curso/info/' + row.id
        }).done(function(data) {
            data = $.parseJSON(data);
            plan_estudio = $.parseJSON(data['plan_estudio']);

            // Agrega los planes de estudio del curso.
            $.each(plan_estudio, function(k, v) {
                setear_plan(v.id_asignatura, v.horas);
            });
        });

        // Elimina el plan utilizado como template.
        $('.plan').first().remove();

        $('#enviar').val($(this).val());
        $('#crud').slideDown();
        $('#glosa').focus();
    } else {
        alert(sel_msg);
    }
});

$('#agregar').on('click', function() {
    $(this).blur();
    $('.listado').find("input[type=radio]").prop('checked', false);
    $('#crud h3').text($(this).val());

    $('#glosa').val('');
    $('#id_profesor').val('');
    $('#comentario').val('');

    resetear_planes();

    $('#enviar').val($(this).val());
    $('#crud').slideDown();
    $('#glosa').focus();
});

$('#eliminar').on('click', function(e) {
    if ($('.listado').find("input[type=radio]:checked").length === 0) {
        e.preventDefault();
        alert(sel_msg);
    } else {
        $('#crud').slideUp();
        if (window.confirm(del_msg) === true) {
            $('#glosa').prop('disabled', true);
            $('#id_profesor').prop('disabled', true);
        } else {
            e.preventDefault();
        }
    }
});

$('#agregar_plan').on('click', function() {
    setear_plan('', '', 0).find('.asignatura').focus();
});

$('#plan_estudio').on('click', '.x_plan', function() {
    $(this).parent().remove();
});

$('#plan_estudio').on('keydown', '.horas:last', function(e) {
    e.stopPropagation();

    if (event.keyCode === 9) {
        setear_plan('', '', 0).find('.asignatura').focus();
        
        return false;
    }
});