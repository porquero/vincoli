$('#delegate').on('click', '.x_form', function() {
    $('#crud').slideUp();
});

$('#delegate').on('click', '.listado tbody tr', function() {
    var radio = $(this).find("input[type=radio]").first();
    radio.prop("checked", !radio.is(':checked'));
    $('#crud').slideUp({duration: 250});
    $('html, body').animate({
        scrollTop: $("#menu").offset().top
    }, 250);
});

$('#fcrud').on('keypress', 'input:not([type=submit])', function(event) {
    if (event.keyCode === 10 || event.keyCode === 13)
        event.preventDefault();
});

$('#delegate').on('keydown', 'input[type=number]', function(e) {
    var key = e.which || e.keyCode || e.charCode;

    if (key === 8) {
        var s = $(this).val();
        s = s.substring(0, s.length - 1);
        $(this).val(s);
        return false;
    }
});