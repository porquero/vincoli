<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * IMPORTANT: To accelerate development I'll minimize coding OO rules.
 *
 * @author porquero
 */
class asignatura extends \MX_Controller {

    /**
     * Connecto to DB.
     */
    public function __construct() {
        parent::__construct();

        $conn = @mysql_connect('localhost', 'root', '123456');
        if (!$conn) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db('vincoli', $conn);
    }

    /**
     * Insert data into table and send json with result
     *
     * @param type $table_name
     */
    public function create() {
        $firstname = $_REQUEST['firstname'];
        $lastname = $_REQUEST['lastname'];
        $phone = $_REQUEST['phone'];
        $email = $_REQUEST['email'];

        $sql = "insert into asignatura(firstname,lastname,phone,email) values('{$firstname}'"
                . ", '{$lastname}', '{$phone}', '{$email}')";
        @mysql_query($sql);
        echo @json_encode(array(
            'id' => mysql_insert_id(),
            'firstname' => $firstname,
            'lastname' => $lastname,
            'phone' => $phone,
            'email' => $email
        ));
    }

    /**
     * Get data from table and send it in json format.
     *
     */
    public function read() {
        $rs = mysql_query('select * from asignatura');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
            array_push($result, $row);
        }

        echo @json_encode($result);
    }

    public function update() {
        $id = intval($_REQUEST['id']);
        $firstname = $_REQUEST['firstname'];
        $lastname = $_REQUEST['lastname'];
        $phone = $_REQUEST['phone'];
        $email = $_REQUEST['email'];

        $sql = "update asignatura set firstname='$firstname',lastname='$lastname',phone='$phone',email='$email' where id=$id";
        @mysql_query($sql);
        echo json_encode(array(
            'id' => $id,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'phone' => $phone,
            'email' => $email
        ));
    }

    public function delete() {
        $id = intval($_REQUEST['id']);

        $sql = "delete from asignatura where id=$id";
        @mysql_query($sql);
        echo json_encode(array('success' => true));
    }

}

$_ns = __NAMESPACE__;
