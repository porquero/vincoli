<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * CRUD for cursos
 * IMPORTANT: To accelerate development I'll minimize coding OO rules.
 *
 * @author porquero
 */
class carga_academica extends \MX_Controller {

    /**
     * Connecto to DB.
     */
    public function __construct() {
        parent::__construct();

        $conn = @mysql_connect('localhost', 'root', '123456');
        if (!$conn) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db('vincoli', $conn);
    }

    public function index() {
        $this->tpl->variables(array(
            'title' => 'Profesores',
            'url_create' => site_url('system/carga_academica/create'),
            'url_read' => site_url('system/carga_academica/read'),
            'url_update' => site_url('system/carga_academica/update'),
            'url_delete' => site_url('system/carga_academica/delete'),
        ));

        $this->tpl->variables(array(
            'dias' => \Modules::run('vincoli\system/dia/json_fetch')
        ));
        $this->tpl->load_view('crud_carga_academica.phtml');
    }

    /**
     * Insert data into table and send json with result
     *
     * @param type $table_name
     */
    public function create() {
        $id_profesor = utf8_decode($_REQUEST['id_profesor']);
        $id_asignatura = utf8_decode($_REQUEST['id_asignatura']);
        $id_curso = utf8_decode($_REQUEST['id_curso']);
        $id_bloque = utf8_decode($_REQUEST['id_bloque']);
        $id_dia = utf8_decode($_REQUEST['id_dia']);
        $comentario = utf8_decode($_REQUEST['comentario']);

        $sql = <<<PQR
INSERT INTO  `carga_academica` (
`id_profesor` ,
`id_asignatura` ,
`id_curso` ,
`id_bloque` ,
`id_dia` ,
`comentario`
)
VALUES (
NULL ,  '{$id_profesor}',  '{$id_asignatura}',  '{$id_curso}',  '{$id_bloque}',  '{$id_dia}',  '{$comentario}');

PQR;
        @mysql_query($sql);
        echo @json_encode(array(
            'id' => mysql_insert_id(),
        ));
    }

    /**
     * Get data from table and send it in json format.
     *
     */
    public function read() {
        $q = <<<PQR
SELECT ca . * , CONCAT( p.nombres,  ' ', p.apellidos ) nombre_profesor, a.glosa nombre_asignatura,
    c.glosa nombre_curso, b.rango nombre_bloque, d.glosa nombre_dia
FROM carga_academica ca
LEFT JOIN profesor p ON p.id = ca.id_profesor
LEFT JOIN asignatura a ON a.id = ca.id_asignatura
LEFT JOIN curso c ON c.id = ca.id_curso
LEFT JOIN bloque b ON b.id = ca.id_bloque
LEFT JOIN dia d ON d.id = ca.id_dia
PQR;
        $rs = mysql_query($q);
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
//            array_push($result, $row);
            $result[] = array(
                'id_profesor' => $row->id_profesor,
                'nombre_profesor' => utf8_encode($row->nombre_profesor),
                'id_asignatura' => utf8_encode($row->id_asignatura),
                'nombre_asignatura' => utf8_encode($row->nombre_asignatura),
                'id_curso' => utf8_encode($row->id_curso),
                'nombre_curso' => utf8_encode($row->nombre_curso),
                'id_bloque' => utf8_encode($row->id_bloque),
                'nombre_bloque' => utf8_encode($row->nombre_bloque),
                'id_dia' => utf8_encode($row->id_dia),
                'nombre_dia' => utf8_encode($row->nombre_dia),
                'comentario' => utf8_encode($row->comentario),
            );
        }

        echo json_encode($result);
    }

    public function update() {
        $id_profesor = utf8_decode($_REQUEST['id_profesor']);
        $id_asignatura = utf8_decode($_REQUEST['id_asignatura']);
        $id_curso = utf8_decode($_REQUEST['id_curso']);
        $id_bloque = utf8_decode($_REQUEST['id_bloque']);
        $id_dia = utf8_decode($_REQUEST['id_dia']);
        $comentario = utf8_decode($_REQUEST['comentario']);

        $sql = <<<PQR
UPDATE  `carga_academica`
SET`id_profesor` =  '{$id_profesor}',
`id_asignatura` =  '{$id_asignatura}',
`id_curso` =  '{$id_curso}',
`id_bloque` =  '{$id_bloque}',
`id_dia` =  '{$id_dia}',
`comentario` =  '{$comentario}'
WHERE  `carga_academica`.`id` ={$id};
PQR;
        @mysql_query($sql);
        echo json_encode(array(
            'id' => $id,
        ));
    }

    public function delete() {
        $id = intval($_REQUEST['id']);

        $sql = "delete from carga_academica where id=$id";
        @mysql_query($sql);
        echo json_encode(array('success' => true));
    }

}

$_ns = __NAMESPACE__;
