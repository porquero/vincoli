<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * CRUD for cursos
 * IMPORTANT: To accelerate development I'll minimize coding OO rules.
 *
 * @author porquero
 */
class profesor extends \MX_Controller {

    /**
     * Connecto to DB.
     */
    public function __construct() {
        parent::__construct();

        $conn = @mysql_connect('localhost', 'root', '123456');
        if (!$conn) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db('vincoli', $conn);
    }

    public function index() {
        $this->tpl->variables(array(
            'title' => 'Profesores',
            'url_create' => site_url('system/profesor/create'),
            'url_read' => site_url('system/profesor/read'),
            'url_update' => site_url('system/profesor/update'),
            'url_delete' => site_url('system/profesor/delete'),
        ));

//        $this->tpl->section('_view', 'index.phtml');
        $this->tpl->load_view('crud_profesor.phtml');
    }

    /**
     * Insert data into table and send json with result
     *
     * @param type $table_name
     */
    public function create() {
        $nombres = utf8_decode($_REQUEST['nombres']);
        $apellidos = utf8_decode($_REQUEST['apellidos']);
        $horas_contrato = utf8_decode($_REQUEST['horas_contrato']);
        $horas_aula = utf8_decode($_REQUEST['horas_aula']);
        $horas_no_lectivas = utf8_decode($_REQUEST['horas_no_lectivas']);
        $horas_permanencia = utf8_decode($_REQUEST['horas_permanencia']);
        $trabajo_tecnico = utf8_decode($_REQUEST['trabajo_tecnico']);
        $comentario = utf8_decode($_REQUEST['comentario']);

        $sql = <<<PQR
INSERT INTO  `profesor` (
`id` ,
`nombres` ,
`apellidos` ,
`horas_contrato` ,
`horas_aula` ,
`horas_no_lectivas` ,
`horas_permanencia` ,
`trabajo_tecnico` ,
`comentario`
)
VALUES (
NULL ,  '{$nombres}',  '{$apellidos}',  '{$horas_contrato}',  '{$horas_aula}',  '{$horas_no_lectivas}'
    ,  '{$horas_permanencia}',  '{$trabajo_tecnico}',  '{$comentario}'
);

PQR;
        @mysql_query($sql);
        echo @json_encode(array(
            'id' => mysql_insert_id(),
        ));
    }

    /**
     * Get data from table and send it in json format.
     *
     */
    public function read() {
        $rs = mysql_query('select * from profesor');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
//            array_push($result, $row);
            $result[] = array(
                'id' => $row->id,
                'nombres' => utf8_encode($row->nombres),
                'apellidos' => utf8_encode($row->apellidos),
                'horas_contrato' => utf8_encode($row->horas_contrato),
                'horas_aula' => utf8_encode($row->horas_aula),
                'horas_no_lectivas' => utf8_encode($row->horas_no_lectivas),
                'horas_permanencia' => utf8_encode($row->horas_permanencia),
                'trabajo_tecnico' => utf8_encode($row->trabajo_tecnico),
                'comentario' => utf8_encode($row->comentario),
            );
        }

        echo json_encode($result);
    }

    public function update() {
        $id = intval($_REQUEST['id']);
        $nombres = utf8_decode($_REQUEST['nombres']);
        $apellidos = utf8_decode($_REQUEST['apellidos']);
        $horas_contrato = utf8_decode($_REQUEST['horas_contrato']);
        $horas_aula = utf8_decode($_REQUEST['horas_aula']);
        $horas_no_lectivas = utf8_decode($_REQUEST['horas_no_lectivas']);
        $horas_permanencia = utf8_decode($_REQUEST['horas_permanencia']);
        $trabajo_tecnico = utf8_decode($_REQUEST['trabajo_tecnico']);
        $comentario = utf8_decode($_REQUEST['comentario']);

        $sql = <<<PQR
UPDATE  `profesor`
SET`nombres` =  '{$nombres}',
`apellidos` =  '{$apellidos}',
`horas_contrato` =  '{$horas_contrato}',
`horas_aula` =  '{$horas_aula}',
`horas_no_lectivas` =  '{$horas_no_lectivas}',
`horas_permanencia` =  '{$horas_permanencia}',
`trabajo_tecnico` =  '{$trabajo_tecnico}',
`comentario` =  '{$comentario}'
WHERE  `profesor`.`id` ={$id};
PQR;
        @mysql_query($sql);
        echo json_encode(array(
            'id' => $id,
        ));
    }

    public function delete() {
        $id = intval($_REQUEST['id']);

        $sql = "delete from profesor where id=$id";
        @mysql_query($sql);
        echo json_encode(array('success' => true));
    }

    public function json_fetch() {
        $rs = mysql_query('select * from profesor');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
            $result[] = array(
                'id_profesor' => $row->id,
                'nombre_profesor' => utf8_encode($row->nombres . ' ' . $row->apellidos),
            );
        }

        echo json_encode($result);
    }

}

$_ns = __NAMESPACE__;
