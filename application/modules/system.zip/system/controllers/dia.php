<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * CRUD for cursos
 * IMPORTANT: To accelerate development I'll minimize coding OO rules.
 *
 * @author porquero
 */
class dia extends \MX_Controller {

    /**
     * Connecto to DB.
     */
    public function __construct() {
        parent::__construct();

        $conn = @mysql_connect('localhost', 'root', '123456');
        if (!$conn) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db('vincoli', $conn);
    }

    public function json_fetch() {
        $rs = mysql_query('select * from dia');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
            $result[] = array(
                'id_dia' => $row->id,
                'nombre_dia' => utf8_encode($row->glosa),
            );
        }
        if ($this->input->is_ajax_request()) {
            echo json_encode($result);
        } else {
            return json_encode($result);
        }
    }

}

$_ns = __NAMESPACE__;