<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 *
 * @author porquero
 */
class home extends \MX_Controller {

    /**
     * App home.
     */
    public function index() {
        $this->tpl->variables(array(
            'title' => 'Vincoli - Gestión de Horarios',
        ));
        $this->tpl->load_view('app.phtml');
    }

    /**
     * Welcome view.
     */
    public function welcome() {
        echo 'Selecciona un elemento del menú';
    }

}

$_ns = __NAMESPACE__;
