<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * CRUD for asignaturas
 * IMPORTANT: To accelerate development I'll minimize coding OO rules.
 *
 * @author porquero
 */
class asignatura extends \MX_Controller {

    /**
     * Connecto to DB.
     */
    public function __construct() {
        parent::__construct();

        $conn = @mysql_connect('localhost', 'root', '123456');
        if (!$conn) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db('vincoli', $conn);
    }

    public function index() {
        $this->tpl->variables(array(
            'title' => 'Asignaturas',
            'url_create' => site_url('system/asignatura/create'),
            'url_read' => site_url('system/asignatura/read'),
            'url_update' => site_url('system/asignatura/update'),
            'url_delete' => site_url('system/asignatura/delete'),
        ));

//        $this->tpl->section('_view', 'index.phtml');
        $this->tpl->load_view('crud.phtml');
    }

    /**
     * Insert data into table and send json with result
     *
     * @param type $table_name
     */
    public function create() {
        $glosa = utf8_decode($_REQUEST['glosa']);

        $sql = "insert into asignatura(id,glosa) values(null,'{$glosa}')";
        @mysql_query($sql);
        echo @json_encode(array(
            'id' => mysql_insert_id(),
        ));
    }

    /**
     * Get data from table and send it in json format.
     *
     */
    public function read() {
        $rs = mysql_query('select * from asignatura');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
//            array_push($result, $row);
            $result[] = array('id' => $row->id, 'glosa' => utf8_encode($row->glosa));
        }

        echo json_encode($result);
    }

    public function update() {
        $id = intval($_REQUEST['id']);
        $glosa = utf8_decode($_REQUEST['glosa']);

        $sql = "update asignatura set glosa='$glosa' where id=$id";
        @mysql_query($sql);
        echo json_encode(array(
            'id' => $id,
            'glosa' => $glosa,
        ));
    }

    public function delete() {
        $id = intval($_REQUEST['id']);

        $sql = "delete from asignatura where id=$id";
        @mysql_query($sql);
        echo json_encode(array('success' => true));
    }

    public function json_fetch() {
        $rs = mysql_query('select * from asignatura');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
            $result[] = array(
                'id_asignatura' => $row->id,
                'nombre_asignatura' => utf8_encode($row->glosa),
            );
        }

        echo json_encode($result);
    }

}

$_ns = __NAMESPACE__;
