<?php

namespace vincoli;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * CRUD for cursos
 * IMPORTANT: To accelerate development I'll minimize coding OO rules.
 *
 * @author porquero
 */
class bloque extends \MX_Controller {

    /**
     * Connecto to DB.
     */
    public function __construct() {
        parent::__construct();

        $conn = @mysql_connect('localhost', 'root', '123456');
        if (!$conn) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db('vincoli', $conn);
    }

    public function index() {
        $this->tpl->variables(array(
            'title' => 'Bloques',
            'url_create' => site_url('system/curso/create'),
            'url_read' => site_url('system/bloque/read'),
            'url_update' => site_url('system/bloque/update'),
            'url_delete' => site_url('system/bloque/delete'),
        ));

//        $this->tpl->section('_view', 'index.phtml');
        $this->tpl->load_view('crud.phtml');
    }

    /**
     * Insert data into table and send json with result
     *
     * @param type $table_name
     */
    public function create() {
        $rango = utf8_decode($_REQUEST['rango']);

        $sql = "insert into bloque(id,rango) values(null,'{$rango}')";
        @mysql_query($sql);
        echo @json_encode(array(
            'id' => mysql_insert_id(),
        ));
    }

    /**
     * Get data from table and send it in json format.
     *
     */
    public function read() {
        $rs = mysql_query('select * from bloque');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
//            array_push($result, $row);
            $result[] = array('id' => $row->id, 'rango' => utf8_encode($row->rango));
        }

        echo json_encode($result);
    }

    public function update() {
        $id = intval($_REQUEST['id']);
        $rango = utf8_decode($_REQUEST['rango']);

        $sql = "update bloque set rango='$rango' where id=$id";
        @mysql_query($sql);
        echo json_encode(array(
            'id' => $id,
            'rango' => $rango,
        ));
    }

    public function delete() {
        $id = intval($_REQUEST['id']);

        $sql = "delete from bloque where id=$id";
        @mysql_query($sql);
        echo json_encode(array('success' => true));
    }

    public function json_fetch() {
        $rs = mysql_query('select * from bloque');
        $result = array();
        while ($row = mysql_fetch_object($rs)) {
            $result[] = array(
                'id_bloque' => $row->id,
                'nombre_bloque' => utf8_encode($row->rango),
            );
        }

        echo json_encode($result);
    }

}

$_ns = __NAMESPACE__;
